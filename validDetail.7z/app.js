function readUserData() {
	var data = {};
	data.uname = document.querySelector("#uname").value;
	if (data.uname == '') {
		document.querySelector("#unameErr").style.display = 'block';
		return;
	}

	data.fvalue = document.querySelector("#fval").value;
	if (data.fvalue == '') {
		document.querySelector("#fvalErr").style.display = 'block';
		return;
	}
	data.fvalue = parseInt(data.fvalue);
	data.svalue = document.querySelector("#sval").value;
	data.svalue = parseInt(data.svalue);
	processData(data);
}

function processData(data) {
	var result = 0;
	result= data.fvalue + data.svalue;
	document.querySelector("#rBlock").innerHTML = "<b>" + result + "</b>";
}


function validaData(event) {
	if (event.charCode >= 48 && event.charCode <= 57) {
		return true;
	}
	return false;
}
function validName(event) {
	console.log(event.charCode);

	if (event.charCode >=97  && event.charCode <= 122) {
		return true;
	}

	if (event.charCode >=65 && event.charCode <= 90) {
		return true;
	}
	return false;
}
